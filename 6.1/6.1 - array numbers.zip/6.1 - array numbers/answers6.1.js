// const arr = [1,2,3,7,5];


// //asnwer 6.1.1
// for (let i = 0; i < arr.length; i++) {
//     console.log(arr[i])
// }

//6.1.2 - NOT GOODDDDDD!!!
// const arrayLength = () => {
//     let count = 0;
//     while (arr.pop() !== undefined) {
//         count++;
//     }
//     return count;
// }

//console.log(arrayLength())
//zehava answer :
// const arr = ["itay","avi","Asf","asf"];
// let last =arr.pop(); //return the last item
// console.log(arr.push(last)) //push the new item
// console.log(arr)

//eyal answer
// const arrayLength = (array) =>{
//     let newArray =[]
//     let n = 0
//
//     for (let i = 0 ; array > newArray ; i++ ){
//         n = n + 1
//         newArray.push(array[i])
//     }
//     console.log(n)
//     return n
// }
//
// console.log(arrayLength([]))

//
// let nums = [1,2,3,4,6];
// console.log(nums[nums.length-1])
// nums.indexOf(nums.slice(-1)[0])


//6.1.2 + 6.1.3
let nums = [1,2,3,4,6];
let sum =0 ;
let mul = 1;
for(let i=0 ; i < nums.length ; i++){
    sum = sum + nums[i];
    //sum+=nums[i];
    //mul*=nums[i];
}

console.log(
    [1,4,5].reduce((a, b) => a * b, 10)
);
